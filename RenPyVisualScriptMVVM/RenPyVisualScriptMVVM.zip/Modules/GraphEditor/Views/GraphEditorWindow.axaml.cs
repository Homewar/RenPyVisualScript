using System;
using System.Linq;
using System.Threading.Tasks;
using Avalonia.Controls;
using Avalonia.Input;
using RenPyVisualScriptMVVM.Core.Models;
using RenPyVisualScriptMVVM.Modules.Editors.Services.Interfaces;
using RenPyVisualScriptMVVM.Modules.GraphEditor.Models;
using RenPyVisualScriptMVVM.Modules.GraphEditor.Services;
using RenPyVisualScriptMVVM.Modules.GraphEditor.ViewModels;
using RenPyVisualScriptMVVM.Modules.Shell.Services.Interfaces;
using RenPyVisualScriptMVVM.Modules.Shell.ViewModels;
using Splat;

namespace RenPyVisualScriptMVVM.Modules.GraphEditor.Views
{
    public partial class GraphEditorWindow : Window
    {
        public GraphEditorWindow()
        {
            InitializeComponent();
            Opened += (_, _) => ApplyGraph(preserveCurrentViewport: false);
            DataContextChanged += OnDataContextChanged;
            Closing += (_, _) => SaveViewState();
            KeyDown += OnWindowKeyDown;
            GraphCanvas.GraphChanged += (_, _) => UpdateStats();
            RoutesListBox.SelectionChanged += (_, _) => OnRouteSelectionChanged();
            RoutesListBox.DoubleTapped += OnRoutesListBoxDoubleTapped;
        }

        private GraphEditorWindowViewModel? _subscribedViewModel;

        private void OnDataContextChanged(object? sender, EventArgs e)
        {
            if (_subscribedViewModel is not null)
                _subscribedViewModel.SnapshotRefreshed -= OnSnapshotRefreshed;

            _subscribedViewModel = DataContext as GraphEditorWindowViewModel;
            if (_subscribedViewModel is not null)
                _subscribedViewModel.SnapshotRefreshed += OnSnapshotRefreshed;

            ApplyGraph(preserveCurrentViewport: false);
        }

        private void OnSnapshotRefreshed()
        {
            ApplyGraph(preserveCurrentViewport: true);
        }

        private void ApplyGraph(bool preserveCurrentViewport)
        {
            if (DataContext is not GraphEditorWindowViewModel vm)
                return;

            Title = vm.Title;
            var currentViewState = preserveCurrentViewport
                ? GraphCanvas.BuildViewState()
                : null;

            var (nodes, edges) = vm.BuildGraph();
            GraphCanvas.Nodes.Clear();
            GraphCanvas.Edges.Clear();
            GraphCanvas.Nodes.AddRange(nodes);
            GraphCanvas.Edges.AddRange(edges);
            var viewState = GraphViewStateStore.Load(vm.ProjectPath);
            GraphCanvas.LoadRoutes(viewState.Routes);
            GraphCanvas.LoadNotes(viewState.Notes);
            var ideSettings = Locator.Current.GetService<IDESettings>();
            if (ideSettings?.AutoLayoutGraphLabels == false)
            {
                GraphCanvas.ApplySavedNodePositions(viewState.NodePositions);
            }
            GraphCanvas.RebuildChildren();
            if (currentViewState?.HasViewport == true)
            {
                GraphCanvas.ApplyViewport(currentViewState.ViewportOffsetX, currentViewState.ViewportOffsetY, currentViewState.ViewportScale);
            }
            else if (viewState.HasViewport)
            {
                GraphCanvas.ApplyViewport(viewState.ViewportOffsetX, viewState.ViewportOffsetY, viewState.ViewportScale);
            }
            else
            {
                GraphCanvas.FocusWorldPoint(new Avalonia.Point(-400, 200));
            }
            GraphCanvas.NotifyGraphChanged();
            UpdateRoutesPanel();
        }

        private async void OnWindowKeyDown(object? sender, KeyEventArgs e)
        {
            if (e.Source is TextBox)
                return;

            if (e.Key == Key.Escape)
            {
                GraphCanvas.ClearRouteHighlight();
                e.Handled = true;
                return;
            }

            if (e.Key == Key.R && e.KeyModifiers.HasFlag(KeyModifiers.Control))
            {
                e.Handled = GraphCanvas.TryBeginRenameSelectedNode();
                return;
            }

            if (e.Key == Key.S && e.KeyModifiers.HasFlag(KeyModifiers.Control))
            {
                await SaveGraphAsync();
                e.Handled = true;
            }
        }

        private async Task SaveGraphAsync()
        {
            if (DataContext is not GraphEditorWindowViewModel vm)
                return;

            try
            {
                GraphCanvas.SyncRouteNodes();
                SaveViewState();
                var result = GraphRpyExporter.SynchronizeGraph(vm.ProjectPath, vm.Snapshot, GraphCanvas.Nodes, GraphCanvas.Edges);
                await vm.RefreshSnapshotFromProjectAsync();
                vm.NotifyGraphSaved(result.UpdatedFiles);
                var windows = Locator.Current.GetService<IWindowService>();
                if (windows != null)
                {
                    var fileList = result.UpdatedFiles.Count == 0
                        ? "Файлы не изменились."
                        : string.Join("\n", result.UpdatedFiles.Select(path => $"• {path}"));

                    var renameInfo = result.RenamedNodeMap.Count == 0
                        ? string.Empty
                        : "\n\nПереименованы узлы:\n" + string.Join("\n", result.RenamedNodeMap.Select(pair => $"• {pair.Key} → {pair.Value}"));

                    await windows.ShowDialogAsync(new MessageDialogViewModel(
                        "Синхронизация завершена",
                        $"Обновлено файлов: {result.UpdatedFiles.Count}\nСинхронизировано узлов: {result.SyncedNodeCount}\nУдалено label: {result.DeletedNodeCount}\nСвязей обработано: {result.SyncedEdgeCount}\n\n{fileList}{renameInfo}"));
                }
            }
            catch (Exception ex)
            {
                var windows = Locator.Current.GetService<IWindowService>();
                if (windows != null)
                {
                    await windows.ShowDialogAsync(new MessageDialogViewModel(
                        "Ошибка синхронизации",
                        ex.Message));
                }
            }
        }

        private void UpdateStats()
        {
            StatsTextBlock.Text = $"Nodes: {GraphCanvas.Nodes.Count}   Edges: {GraphCanvas.Edges.Count}";
            UpdateRoutesPanel();
        }

        private void UpdateRoutesPanel()
        {
            var selectedRouteName = (RoutesListBox.SelectedItem as StoryRoute)?.Name;
            var routes = GraphCanvas.Routes
                .OrderBy(route => route.Name, StringComparer.OrdinalIgnoreCase)
                .ToList();

            RoutesListBox.ItemsSource = routes;

            if (!string.IsNullOrWhiteSpace(selectedRouteName))
            {
                RoutesListBox.SelectedItem = routes.FirstOrDefault(route =>
                    string.Equals(route.Name, selectedRouteName, StringComparison.OrdinalIgnoreCase));
            }

            if (RoutesListBox.SelectedItem is null && routes.Count > 0)
            {
                RoutesListBox.SelectedIndex = 0;
            }

            OnRouteSelectionChanged();
        }

        private void OnRouteSelectionChanged()
        {
            var selectedRoute = RoutesListBox.SelectedItem as StoryRoute;
            GraphCanvas.ActiveRouteName = selectedRoute?.Name;
            RouteNodesListBox.ItemsSource = selectedRoute?.NodeTitles?.OrderBy(title => title).ToList()
                ?? Enumerable.Empty<string>();
        }

        private void OnRoutesListBoxDoubleTapped(object? sender, TappedEventArgs e)
        {
            if (RoutesListBox.SelectedItem is not StoryRoute route)
                return;

            GraphCanvas.ToggleRouteHighlight(route);
            e.Handled = true;
        }

        private void OnClearRouteHighlightClick(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
        {
            GraphCanvas.ClearRouteHighlight();
            e.Handled = true;
        }

        private async void OnRenameRouteMenuItemClick(object? sender, Avalonia.Interactivity.RoutedEventArgs e)
        {
            if (sender is not MenuItem { CommandParameter: StoryRoute route })
                return;

            RoutesListBox.SelectedItem = route;
            await RenameRouteAsync(route);
            e.Handled = true;
        }

        private async Task RenameRouteAsync(StoryRoute route)
        {
            var dialogs = Locator.Current.GetService<IEditorDialogService>();
            if (dialogs is null)
                return;

            var newName = await dialogs.ShowTextInputDialogAsync(this, "Переименовать route", "Новое имя", route.Name);
            if (string.IsNullOrWhiteSpace(newName)
                || string.Equals(route.Name, newName.Trim(), StringComparison.Ordinal))
            {
                return;
            }

            if (!GraphCanvas.RenameRoute(route, newName))
            {
                await dialogs.ShowMessageAsync(this, "Переименовать route", "Не удалось переименовать route. Проверь, что имя не пустое и не повторяется.");
                return;
            }

            SaveViewState();
            UpdateRoutesPanel();
            RoutesListBox.SelectedItem = GraphCanvas.Routes.FirstOrDefault(candidate =>
                string.Equals(candidate.Name, newName.Trim(), StringComparison.OrdinalIgnoreCase));
            OnRouteSelectionChanged();
        }

        private void SaveViewState()
        {
            if (DataContext is not GraphEditorWindowViewModel vm)
                return;

            GraphCanvas.SyncRouteNodes();
            GraphViewStateStore.Save(vm.ProjectPath, GraphCanvas.BuildViewState());
        }
    }
}
